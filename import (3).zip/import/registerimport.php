<?php
error_reporting(0);
$con = mysqli_connect('localhost', 'root', '', 'grampanchayat');
if (isset($_POST['submit'])) {
    $file = $_FILES['doc']['tmp_name'];

    $ext = pathinfo($_FILES['doc']['name'], PATHINFO_EXTENSION);
    if ($ext == 'xlsx') {
        require('PHPExcel/PHPExcel.php');
        require('PHPExcel/PHPExcel/IOFactory.php');

        $obj = PHPExcel_IOFactory::load($file);
        foreach ($obj->getWorksheetIterator() as $sheet) {
            $getHighestRow = $sheet->getHighestRow();
            for ($i = 0; $i <= $getHighestRow; $i++) {
                $username = $sheet->getCellByColumnAndRow(0, $i)->getValue();
                $password = $sheet->getCellByColumnAndRow(1, $i)->getValue();
                $folder = $sheet->getCellByColumnAndRow(2, $i)->getValue();  

                if ($username != '') {
                    mysqli_query($con, "insert into admin (username,password,image) values('$uname','$password','$folder')");
                }
            }
        }
    } else {
        echo "Invalid file format";
    }
}
?>

<form method="post" enctype="multipart/form-data">
    <input type="file" name="doc" />
    <input type="submit" name="submit" />
</form>
